<html>
<body><p><h2>Something is wrong with your request (like the page your are looking for does not exist).</h2>
Please try after some time or <a href="/">click here</a> to go to Home Page.</p>
<script>
        setTimeout(function (){
           window.location.href = "/";
       },5000)
    </script>
</body>
</html>
